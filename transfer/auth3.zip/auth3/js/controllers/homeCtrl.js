app.controller('homeCtrl', function($scope){
	$scope.title = "Hello Home!"
})
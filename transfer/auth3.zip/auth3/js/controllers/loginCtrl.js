app.controller('loginCtrl', function($scope, loginService){
	 $scope.login = function(credentials){
	 	//console.log(credentials);
	 	loginService.login(credentials);
	 };

});
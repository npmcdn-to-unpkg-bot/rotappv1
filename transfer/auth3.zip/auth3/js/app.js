var app = angular.module('Rotappv1', ['ngRoute']);
app.config(function($routeProvider){
  
  $routeProvider
  .when('/login', {templateUrl:'partials/login.html', controller:'loginCtrl'})
  .when('/home', {templateUrl:'partials/home.html', controller:'homeCtrl'})
  .otherwise({redirectTo: '/login'});
});

app.run(function($rootScope, $location, loginService){
  var routesPermission = ['/home'];
  $rootScope.$on('$routeChangeStart', function(){
    if( routesPermission.indexOf($location.path()) !=-1) // && !loginService.islogged()
    {
      var connected=loginService.islogged();
      connected.then(function(msg){
        if(!msg.data) { $location.path ('/login'); }
      });
    }
  });
});

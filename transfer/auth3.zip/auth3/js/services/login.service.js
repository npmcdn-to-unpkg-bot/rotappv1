app.factory('loginService', function($http, $location, sessionService){
	return{
		login:function(data){
			//console.log(data);
			// Send data to user.php
			var $promisse=$http.post('data/user.php', data) 

			$promisse.then(function(msg){
				console.log(msg);
				var uid = msg.data;
				if(uid){
					sessionService.set('user', uid);
					$location.path('/home');
				}else if(uid == '') {
					console.log('Negado');
					//$scope.msgTxt='incorrect information';
					$location.path('/login');
				}
			});
		},

		logout: function(){
			sessionService.destroy('user');
			$location.path('/login');
		},

		islogged:function(){
			
			var $checkSessionServer=$http.post('data/check_session.php');
			return $checkSessionServer;

			// if(sessionService.get('user')){ 
			// 	return true;
			// } else{
			// 	return false;
			// };
		}

	}
})
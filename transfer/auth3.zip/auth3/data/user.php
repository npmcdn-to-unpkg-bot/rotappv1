<?php 

$user = json_decode(file_get_contents("php://input"));
if($user->email=='lucas.design@globo.com' && $user->password=='123'){
	session_start();
	$_SESSION['uid']=uniqid('ang_');
	print $_SESSION['uid'];
}

	// $postdata = file_get_contents("php://input");
	// $request = json_decode($postdata);
	// @$email = $request->email;
	// @$senha = $request->pass;
	
	
	// $id = null;

	// // Caso a consulta retorne 0...

	// echo json_encode($id);

	 

?>
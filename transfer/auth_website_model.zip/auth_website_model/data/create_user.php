<?php 

	$user = json_decode(file_get_contents("php://input"));

	@$nome = $user->nome;
	@$email = $user->email;
	@$senha = $user->senha;

	//echo json_encode($nome);

	$user = array();
	$user['nome'] 	= $nome;
	$user['email'] 	= $email;
	$user['senha']	= $senha;

	include("pdo.php");

	try {
		$stmt = $pdo->prepare("INSERT INTO usuario (nome, email, senha) VALUES (:nome, :email, :senha)");
		$stmt->bindValue(":nome", $nome);
		$stmt->bindValue(":email", $email);
		$stmt->bindValue(":senha", $senha);
		$stmt->execute();

		echo $stmt->rowCount();

	} catch (Exception $e) {
			echo "Error:" . $e->getMessage();
	}

?>
<?php 

	phpinfo();
 ?>
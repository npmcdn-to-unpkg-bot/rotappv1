<?php 

	$user = json_decode(file_get_contents("php://input"));
	
	$email = $user->email;
	$senha = $user->password;

	include("pdo.php");

	try {

		// Alterar chaves do array para padronizar a nomenclatura
		$stmt = $pdo->query("SELECT * FROM usuario WHERE email = '$email' and senha = '$senha'");
		
		if($stmt->rowCount() != 1){
			
		}else{
				session_start();
				$_SESSION['uid']=uniqid('ang_');
				print $_SESSION['uid'];			
		};
		
	} catch (PDOException $e) {
		echo "Error" . $e->getMessage();
	}

?>
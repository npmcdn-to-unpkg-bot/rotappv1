app.controller('homeCtrl', function($scope, loginService){
	$scope.title = "Hello Home!";

	$scope.logout = function(){
		loginService.logout();
	};

	
});
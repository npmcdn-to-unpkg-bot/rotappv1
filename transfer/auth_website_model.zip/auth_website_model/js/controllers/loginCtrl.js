app.controller('loginCtrl', function($scope, loginService, sessionService, userService){
	 $scope.login = function(credentials){
	 	//console.log(credentials);
	 	loginService.login(credentials);
	 };

	$scope.authElements = function(){
		// Checar se usuário está logado...?
		// data/check_session.php ??
		// session?
		if(sessionStorage.getItem('uid') !== null){
			$scope.logged = true;
			console.log($scope.logged);
		} else {
			$scope.logged = false;
			console.log($scope.logged);
		}
	};

	$scope.switchForms = function(){
		
		if($scope.novoUsuario == false){
			$scope.novoUsuario = true;
		}else{
			$scope.novoUsuario = false
		}
	};

	$scope.createNewUser = function(user){
		userService.create(user);
		console.log(user);
	};

	$scope.authElements();	 

});
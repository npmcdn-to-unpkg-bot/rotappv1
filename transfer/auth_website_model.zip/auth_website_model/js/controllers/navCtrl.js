app.controller('navCtrl', function($scope, sessionService){
	$scope.authElements = function(){
		// Checar se usuário está logado...?
		// data/check_session.php ??
		// session?
		if(sessionStorage.getItem('uid') !== null){
			$scope.logged = true;
			console.log('navCtrl : '+$scope.logged);
		} else {
			$scope.logged = false;
			console.log($scope.logged);
		}
	};

	$scope.authElements();	 
});
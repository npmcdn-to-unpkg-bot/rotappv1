app.factory('sessionService', function(){
	return{
		set: function(key, value){
			return sessionStorage.setItem(key, value);
		},
		get: function(key){
			return sessionStorage.getItem(key);
		},
		destroy: function(key){
			console.log('Session end');
			return sessionStorage.removeItem(key);

		}				
	};
})
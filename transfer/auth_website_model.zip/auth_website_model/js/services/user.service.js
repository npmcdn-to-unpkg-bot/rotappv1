app.factory('userService', function($http){
	return{
		create:function(user){
			$http.post('data/create_user.php', user)
			.then(function(data){
				 console.log(data.data); // Verificando se tudo foi ok..
			})
		},
		get:function(uid){

		},
		delete:function(uid){

		},
		update:function(uid){
			
		}
	};
})
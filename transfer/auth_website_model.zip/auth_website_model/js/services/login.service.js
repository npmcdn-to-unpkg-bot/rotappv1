app.factory('loginService', function($http, $location, sessionService, userService){
	return{
		login:function(data){
			//console.log(data);
			// Send data to user.php
			var $promisse=$http.post('data/user.php', data) 

			$promisse.then(function(msg){
				console.log(msg.data);
				var uid = msg.data;
				if(uid){
					sessionService.set('uid', uid);
					$location.path('/home');
				}else{
					console.log('Negado');
					//$scope.msgTxt='incorrect information';
					$location.path('/login');
				}
			});
		},

		logout: function(){
			sessionService.destroy('uid');
			var $destroySessuibServer = $http.post('data/destroy_session.php');
			$location.path('/login');
		},

		islogged:function(){
			
			var $checkSessionServer=$http.post('data/check_session.php');
			return $checkSessionServer;
		},

	}
})